/* ************************************************************************** */
/* */
/* Project: Legacy Boolean Representation                                     */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    int is_valid = 1;  // Represents True
    int is_error = 0;  // Represents False

    if (is_valid)
    {
        printf("The data is valid.\n");
    }

    return (0);
}
