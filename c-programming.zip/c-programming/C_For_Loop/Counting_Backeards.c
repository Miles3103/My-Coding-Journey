/* ************************************************************************** */
/* */
/* Project: Countdown Timer                                                   */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    printf("Blast off in...\n");

    for (int i = 3; i > 0; i--)
    {
        printf("%d...\n", i);
    }

    printf("LIFTOFF!\n");

    return (0);
}
