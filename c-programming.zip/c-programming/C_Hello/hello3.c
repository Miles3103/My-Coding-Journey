#include <stdio.h>
int	main(void)
{
	puts("Hello, World!\n");
	return 0;
}
