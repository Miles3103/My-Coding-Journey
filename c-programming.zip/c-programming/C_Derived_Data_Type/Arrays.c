/* ************************************************************************** */
/* */
/* Project: Integer Arrays                                                    */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    // An array of 5 integers
    int    scores[5] = {90, 85, 70, 95, 80};

    // Accessing elements (Index starts at 0)
    printf("First Score: %d\n", scores[0]);
    printf("Third Score: %d\n", scores[2]);

    return (0);
}
