/* ************************************************************************** */
/* */
/* Project: Assignment Shorthand                                              */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    int n = 10;

    n += 5;   // n is now 15
    n++;      // n is now 16

    printf("Final value of n: %d\n", n);

    return (0);
}
