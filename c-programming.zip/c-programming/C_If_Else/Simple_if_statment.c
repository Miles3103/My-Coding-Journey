/* ************************************************************************** */
/* */
/* Project: Simple If Statement                                               */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    int score = 95;

    if (score > 90)
    {
        printf("Excellent work, Miles3103!\n");
    }

    return (0);
}
