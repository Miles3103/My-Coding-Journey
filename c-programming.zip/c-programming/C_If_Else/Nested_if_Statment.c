/* ************************************************************************** */
/* */
/* Project: Nested Logic                                                      */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    int num = 10;

    if (num != 0)
    {
        if (num > 0)
        {
            printf("The number is positive.\n");
        }
        else
        {
            printf("The number is negative.\n");
        }
    }

    return (0);
}
