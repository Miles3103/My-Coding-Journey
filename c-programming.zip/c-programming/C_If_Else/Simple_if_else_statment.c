/* ************************************************************************** */
/* */
/* Project: If-Else Decision                                                  */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    int temperature = 15;

    if (temperature > 25)
    {
        printf("It is a hot day.\n");
    }
    else
    {
        printf("It is a cool day.\n");
    }

    return (0);
}
