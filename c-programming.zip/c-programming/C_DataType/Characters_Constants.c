/* ************************************************************************** */
/* */
/* Project: Character Constants                                               */
/* Author:  Miles3103                                                         */
/* */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
    char    initial = 'M';        // Single quotes for characters (%c)
    char    code = 65;            // ASCII for 'A'

    printf("Initial: %c\n", initial);
    printf("Code %d represents: %c\n", code, code);

    return (0);
}
